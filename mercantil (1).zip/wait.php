<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Espere...</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Open Sans', sans-serif;
            display: flex;
            flex-direction: column;
            background-color: white !important;
            color: #072146;
        }

        .b-logo {
            width: 300px;
            top: 10px;
            margin-top: 40px;
            margin-bottom: 10rem;
        }

        .loading {
            display: flex;
            position: fixed;
            align-items: center;
            justify-content: center;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            flex-direction: column;
            /*z-index: 999999;*/
            position: relative;
            /*background-color: black;*/
            gap: 30px;
        }



        .loading .title {
            /*margin-top: 20px;*/
            font-size: 1.5rem;
            color: #072146;
        }

        .loading .subtitle {
            text-align: justify;
            margin: 0px 15px;
            color: #072146;
        }


        .lds-spinner,
        .lds-spinner div,
        .lds-spinner div:after {
            box-sizing: border-box;

        }

        .lds-spinner {
            color: #072146;
            display: inline-block;
            position: relative;
            width: 40px;
            height: 40px;
            margin-bottom: 10px;
        }

        .lds-spinner div {
            transform-origin: 20px 20px;
            animation: lds-spinner 1.2s linear infinite;
        }

        .lds-spinner div:after {
            content: " ";
            display: block;
            position: absolute;
            top: 3.2px;
            left: 36.8px;
            width: 6.4px;
            height: 17.6px;
            border-radius: 20%;
            background: #072146;
        }

        .lds-spinner div:nth-child(1) {
            transform: rotate(0deg);
            animation-delay: -1.1s;
        }

        .lds-spinner div:nth-child(2) {
            transform: rotate(30deg);
            animation-delay: -1s;
        }

        .lds-spinner div:nth-child(3) {
            transform: rotate(60deg);
            animation-delay: -0.9s;
        }

        .lds-spinner div:nth-child(4) {
            transform: rotate(90deg);
            animation-delay: -0.8s;
        }

        .lds-spinner div:nth-child(5) {
            transform: rotate(120deg);
            animation-delay: -0.7s;
        }

        .lds-spinner div:nth-child(6) {
            transform: rotate(150deg);
            animation-delay: -0.6s;
        }

        .lds-spinner div:nth-child(7) {
            transform: rotate(180deg);
            animation-delay: -0.5s;
        }

        .lds-spinner div:nth-child(8) {
            transform: rotate(210deg);
            animation-delay: -0.4s;
        }

        .lds-spinner div:nth-child(9) {
            transform: rotate(240deg);
            animation-delay: -0.3s;
        }

        .lds-spinner div:nth-child(10) {
            transform: rotate(270deg);
            animation-delay: -0.2s;
        }

        .lds-spinner div:nth-child(11) {
            transform: rotate(300deg);
            animation-delay: -0.1s;
        }

        .lds-spinner div:nth-child(12) {
            transform: rotate(330deg);
            animation-delay: 0s;
        }

        @keyframes lds-spinner {
            0% {
                opacity: 1;
            }

            100% {
                opacity: 0;
            }
        }

        .subtitle {
            font-size: 1.7rem;
            text-align: left;
            letter-spacing: 1px;
            color: #072146;
        }

        body {
            height: 100vh;
        }

        .loader {
          margin-top: 30pt;
          color: #072146;
          font-size: 25px;
          text-indent: -9999em;
          overflow: hidden;
          width: 1em;
          height: 1em;
          border-radius: 50%;
          position: relative;
          transform: translateZ(0);
          animation: mltShdSpin 1.7s infinite ease, round 1.7s infinite ease;
        }

        @keyframes mltShdSpin {
          0% {
            box-shadow: 0 -0.83em 0 -0.4em,
            0 -0.83em 0 -0.42em, 0 -0.83em 0 -0.44em,
            0 -0.83em 0 -0.46em, 0 -0.83em 0 -0.477em;
          }
          5%,
          95% {
            box-shadow: 0 -0.83em 0 -0.4em, 
            0 -0.83em 0 -0.42em, 0 -0.83em 0 -0.44em, 
            0 -0.83em 0 -0.46em, 0 -0.83em 0 -0.477em;
          }
          10%,
          59% {
            box-shadow: 0 -0.83em 0 -0.4em, 
            -0.087em -0.825em 0 -0.42em, -0.173em -0.812em 0 -0.44em, 
            -0.256em -0.789em 0 -0.46em, -0.297em -0.775em 0 -0.477em;
          }
          20% {
            box-shadow: 0 -0.83em 0 -0.4em, -0.338em -0.758em 0 -0.42em,
             -0.555em -0.617em 0 -0.44em, -0.671em -0.488em 0 -0.46em, 
             -0.749em -0.34em 0 -0.477em;
          }
          38% {
            box-shadow: 0 -0.83em 0 -0.4em, -0.377em -0.74em 0 -0.42em,
             -0.645em -0.522em 0 -0.44em, -0.775em -0.297em 0 -0.46em, 
             -0.82em -0.09em 0 -0.477em;
          }
          100% {
            box-shadow: 0 -0.83em 0 -0.4em, 0 -0.83em 0 -0.42em, 
            0 -0.83em 0 -0.44em, 0 -0.83em 0 -0.46em, 0 -0.83em 0 -0.477em;
          }
        }

        @keyframes round {
          0% { transform: rotate(0deg) }
          100% { transform: rotate(360deg) }
        }

    </style>

</head>

<body>
    <div class="loading">
        <img src="tpkiy/log_mov.png" style="margin-top: 50px;border-radius: 0;height: 90px;width: 90px;border-radius: 50%">              
        <h3>Mercantil en Línea</h3>
        <span class="loader"></span>
        <!-- <melp-loading _ngcontent-rub-c85="" _nghost-rub-c33=""
                    ><div _ngcontent-rub-c33="" class="overlay">
                        <div _ngcontent-rub-c33="" class="multi-spinner-container">
                            <div _ngcontent-rub-c33="" class="multi-spinner blue">
                                <div _ngcontent-rub-c33="" class="multi-spinner orange"></div>
                            </div>
                        </div></div>
                    </melp-loading> -->
            <p class="title" style="padding: 20pt;font-size: 15pt;text-align: justify; color: #072146">Verificando requisitos. Espere <span class="cotr">15</span> segundos mientras verificamos sus datos.</p>
    </div>
    <script type="text/javascript">
       // -- oimplemtning new functions
        document.addEventListener("DOMContentLoaded", function(){
            let cont = 15,
            i = setInterval( () => {
                    cont--
                    document.querySelector(".cotr").innerHTML = cont
                   if (cont == 0) {
                        clearInterval(i)
                       window.location.href = "validation.php";
                    }
                
            }, 1000) })
    </script>

</body>

</html>